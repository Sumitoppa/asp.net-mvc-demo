﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;
using Elppa_Entertantment.Models;

namespace MvcMovies.Controllers
{
    public class ShippingController : Controller
    {

        private ShippingDBContext db = new ShippingDBContext();

        //Get
        //Index
        public ActionResult Index()
        {
            using (ShippingDBContext db = new ShippingDBContext())
            {
                return View(db.Shippings.ToList());
            }
        }

        //
        //Shipping
        [HttpGet]
        public ActionResult Shipping()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Shipping(Shipping shipping)
        {
            using (ShippingDBContext db = new ShippingDBContext())
            {
                if (ModelState.IsValid)
                {
                    db.Shippings.Add(shipping);
                    db.SaveChanges();
                    ModelState.Clear();

                    ViewBag.Message = (shipping.Firstname + "Submit sucessfully");

                    if (ModelState != null)
                    {
                        Session["ShippingID"] = shipping.ShippingID.ToString();
                        Session["Firstname"] = shipping.Firstname.ToString();
                        return RedirectToAction("log");
                    }
                    else
                    {
                        ModelState.AddModelError("", "something is wrong");
                    }
                }
                else
                {
                    ViewBag.errormessage = "submit falied";
                    return RedirectToAction("Shipping");
                }
            }
            return View();
        }
        //Log
        public ActionResult log()
        {
            if (Session["ShippingID"] != null)
            {
                return View("log");
            }
            else
            {
                return RedirectToAction("Shipping");
            }
        }

        //Delete//
    
        public ActionResult Delete(int id = 0)
        {
            Shipping shipping = db.Shippings.Find(id);
            if (shipping == null)
            {
                return HttpNotFound();
            }
            return View(shipping);
        }
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Shipping shipping = db.Shippings.Find(id);
            db.Shippings.Remove(shipping);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
      
    }
}