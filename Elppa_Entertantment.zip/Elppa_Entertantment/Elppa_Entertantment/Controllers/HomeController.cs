﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Elppa_Entertantment.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult UpcomingMovies()
        {
            string[] UpcomingMovies = { "Suntan", "Dangal", "Raees" };

            string[] CastStart = { "Salman khan, Anushka Sharma", "Amir khan, Fatima Sana Shaikh", "Sharuk khan, mahira khan" };

            ViewBag.names = UpcomingMovies;
            ViewBag.cast = CastStart;

            return View();
        }
    }
}
