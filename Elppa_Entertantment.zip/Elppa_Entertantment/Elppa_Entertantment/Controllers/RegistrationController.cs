﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using Elppa_Entertantment.Models;

namespace Elppa_Entertantment.Controllers
{
    public class RegistrationController : Controller
    {
        public PublicsDBContext db = new PublicsDBContext();
        //
        // GET: /Registration/

        public ActionResult Index()
        {
            using (PublicsDBContext db = new PublicsDBContext())
            {
                return View(db.MyPublic.ToList());
            }
        }
        [HttpGet]
        public ActionResult Registration()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Registration(Public publics)
        {
            if (ModelState.IsValid)
            {
                using (PublicsDBContext db = new PublicsDBContext())
                {
                    db.MyPublic.Add(publics);
                    db.SaveChanges();
                }
                ModelState.Clear();
                ViewBag.Message = publics.Customer_Name + "Register sucessfully";
            }
            return View();
        }
        /*log in from*/

        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Public pub)
        {
            using (PublicsDBContext db = new PublicsDBContext())
            {
                var usr = db.MyPublic.Single(u => u.Username == pub.Username && u.Password == pub.Password);

                if (usr != null)
                {
                    Session["UserID"] = usr.ID.ToString();
                    Session["Username"] = usr.Username.ToString();
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError("", "Username or Password is wrong.");
                }
            }
            return View();
        }

        /**/
        public ActionResult Logout(string returnurl)
        {
            Session.Remove("Username"); //For logout

            return RedirectToAction("Index", "Home");
        }
        

        //
        // GET: /Person/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Public publc = db.MyPublic.Find(id);
            if (publc == null)
            {
                return HttpNotFound();
            }
            return View(publc);
        }

        //
        // POST: /Person/Edit/5

        [HttpPost]
        public ActionResult Edit(Public publc)
        {
            if (ModelState.IsValid)
            {
                db.Entry(publc).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Login","Registration");
            }
            return View(publc);
        }

      

        //
        // GET: /Account/Man
        /*   public ActionResult LoggedIn()
           {
               if (Session["UserID"] != null)
               {
                   return View();
               }
               else
               {
                   return RedirectToAction("Login");
               }
           }*/



        //close login from//

        /*start external login*/

        
        [HttpGet]
        public ActionResult Delete(long id = 0)
        {
            using (PublicsDBContext db = new PublicsDBContext())
            {
                Public publics = db.MyPublic.Find(id);

                if (ModelState == null)
                {
                    return HttpNotFound();
                }
                return View(publics);
            }

        }
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(long id)
        {
            using (PublicsDBContext db = new PublicsDBContext())
            {
                Public publics = db.MyPublic.Find(id);

                db.MyPublic.Remove(publics);
                db.SaveChanges();
                return RedirectToAction("Registration");
            }
        }
       
    }
}