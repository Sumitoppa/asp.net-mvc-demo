﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Elppa_Entertantment.Models;

namespace Elppa_Entertantment.Controllers
{
    public class MoviesController : Controller
    {
        private MoviemodelDBContext db = new MoviemodelDBContext();

        //
        // GET: /Movies/

        public ActionResult Index(string searchString, string movieGenre)
        {
            
        
            var GenreLst = new List<string>();

            var GenreQry = from d in db.Moviemodels
                           orderby d.Genre
                           select d.Genre;

            GenreLst.AddRange(GenreQry.Distinct());
            ViewBag.movieGenre = new SelectList(GenreLst);

            var movies = from m in db.Moviemodels
                         select m;

            if (!String.IsNullOrEmpty(searchString))
            {
                movies = movies.Where(s => s.Movie_Name.Contains(searchString));
            }

            if (!string.IsNullOrEmpty(movieGenre))
            {
                movies = movies.Where(x => x.Genre == movieGenre);
            }

            return View(movies);
        }
        [HttpPost]
        public string Index(FormCollection fc, string searchString)
        {
            return "<h3> From [HttpPost]Index: " + searchString + "</h3>";
        }
           

        //
        // GET: /Movies/Details/5

        public ActionResult Details(long id = 0)
        {
            Moviemodel moviemodel = db.Moviemodels.Find(id);
            if (moviemodel == null)
            {
                return HttpNotFound();
            }
            return View(moviemodel);
        }

        //
        // GET: /Movies/Create
    
        public ActionResult Create()
        {
            return View();
            
        }

        //
        // POST: /Movies/Create

        [HttpPost]
        public ActionResult Create(Moviemodel moviemodel)
        {
            if (ModelState.IsValid)
            {
                db.Moviemodels.Add(moviemodel);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(moviemodel);
        }

        //
        // GET: /Movies/Edit/5

        public ActionResult Edit(long id = 0)
        {
            Moviemodel moviemodel = db.Moviemodels.Find(id);
            if (moviemodel == null)
            {
                return HttpNotFound();
            }
            return View(moviemodel);
        }

        //
        // POST: /Movies/Edit/5

        [HttpPost]
        public ActionResult Edit(Moviemodel moviemodel)
        {
            if (ModelState.IsValid)
            {
                db.Entry(moviemodel).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(moviemodel);
        }

        //
        // GET: /Movies/Delete/5

        public ActionResult Delete(long id = 0)
        {
            Moviemodel moviemodel = db.Moviemodels.Find(id);
            if (moviemodel == null)
            {
                return HttpNotFound();
            }
            return View(moviemodel);
        }

        //
        // POST: /Movies/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(long id)
        {
            Moviemodel moviemodel = db.Moviemodels.Find(id);
            db.Moviemodels.Remove(moviemodel);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}