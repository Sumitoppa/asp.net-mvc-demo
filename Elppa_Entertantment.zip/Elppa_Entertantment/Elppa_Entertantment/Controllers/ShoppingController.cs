﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using Elppa_Entertantment.Models;
using System.ComponentModel.DataAnnotations;

namespace Elppa_Entertantment.Controllers
{
    public class ShoppingController : Controller
    {
        private ShopDBContext db = new ShopDBContext();
        //
        // GET: /Shopping/

        public ActionResult Index()
        {
            using (ShopDBContext db = new ShopDBContext())
            {
                return View(db.Shops.ToList());
            }
        }
        [HttpGet]
        public ActionResult BookTicket()
        {
            return View();
        }
        [HttpPost]
        public ActionResult BookTicket(Shop shop)
        {
            using (ShopDBContext db = new ShopDBContext())
            {
                if (ModelState.IsValid)
                {
                    db.Shops.Add(shop);
                    db.SaveChanges();
                    ModelState.Clear();



                    ViewBag.Message = (shop.Movie_Name + "Add To cart sucessfully");

                }
                else
                {
                    ViewBag.errormessage = "Shoping failed";
                    return RedirectToAction("Shop");

                }

                return View(shop);

            }
            
        }

        public ActionResult Delete(int id = 0)
        {
            Shop Shops = db.Shops.Find(id);
            if (Shops == null)
            {
                return HttpNotFound();
            }
            return View(Shops);
        }
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Shop Shops = db.Shops.Find(id);
            db.Shops.Remove(Shops);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
