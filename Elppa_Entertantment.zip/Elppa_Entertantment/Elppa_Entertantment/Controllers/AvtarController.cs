﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Elppa_Entertantment.Controllers
{
    public class AvtarController : Controller
    {
        //
        // GET: /Avtar/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult BookTicket()
        {
            return View();

        }
        public ActionResult BookTicketIndex()
        {
            return View();
        }
    }

    
}
