﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Elppa_Entertantment.Controllers
{
    public class JUngleBookController : Controller
    {
        //
        // GET: /JUngleBook/

        public ActionResult Index()
        {
            return View();
        }

    }
}
