$(document).ready(function () {
 
    $(".bhaijaan").mouseover(function () {
        $(this).fadeOut(1000)
    });
    $(".bhaijaan").mouseover(function () {
        $(this).fadeIn(500);
    });
    $(".tarrazemenpar").mouseover(function () {
        $(this).fadeOut(1000)
    });
    $(".tarrazemenpar").mouseover(function () {
        $(this).fadeIn(500);
    });
    $(".idots").mouseover(function () {
        $(this).fadeOut(1000)
    });
    $(".idots").mouseover(function () {
        $(this).fadeIn(500);
    });
    $(".rangdebasanti").mouseover(function () {
        $(this).fadeOut(1000)
    });
    $(".rangdebasanti").mouseover(function () {
        $(this).fadeIn(500);
    });
});