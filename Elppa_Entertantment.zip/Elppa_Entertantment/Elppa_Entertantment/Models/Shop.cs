﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;

namespace Elppa_Entertantment.Models
{
    public class Shop
    {
        [Key]
        public int ID { get; set; }
        [Required]
        public string Movie_Name { get; set; }
        [Required]
        public string Show { get; set; }
        [Required]
        public DateTime Date { get; set; }
        [Required]
        public decimal Ticket_Price { get; set; }
    }
}