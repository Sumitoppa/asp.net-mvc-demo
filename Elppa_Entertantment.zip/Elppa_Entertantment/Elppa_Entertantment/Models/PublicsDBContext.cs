﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;

namespace Elppa_Entertantment.Models
{
    public class PublicsDBContext:DbContext
    {
        public DbSet<Public> MyPublic { get; set; }
    }
}