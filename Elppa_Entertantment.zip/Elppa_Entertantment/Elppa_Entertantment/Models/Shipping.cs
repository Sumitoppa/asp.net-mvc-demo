﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Elppa_Entertantment.Models
{
    public class Shipping
    {
        public int ShippingID { get; set; }

        [Required(ErrorMessage = "please provide your firstname")]
        public string Firstname { get; set; }

        [Required(ErrorMessage = "please provide your address")]
        public string Address { get; set; }

        [Required(ErrorMessage = "please provide your city")]
        public string City { get; set; }

        [Required(ErrorMessage = "please provide your state")]
        public string State { get; set; }

        [Required(ErrorMessage = "please provide your postalcode")]
        [DataType(DataType.PostalCode)]
        public string Postalcode { get; set; }

        [Required(ErrorMessage = "please provide your mobile number")]
        [DataType(DataType.PhoneNumber)]
        public string mobile { get; set; }

        [Required(ErrorMessage = "please provide your email address")]
        [DataType(DataType.EmailAddress)]
        public string emailaddress { get; set; }

        [Required]
        public string Tickets { get; set; }
    }
}