﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;

namespace Elppa_Entertantment.Models
{
    public class Public
    {
        [Key]
        public long ID { get; set; }

        [Required(ErrorMessage = "please provide your name")]
        [StringLength(20, MinimumLength = 4)]
        public string Customer_Name { get; set; }


        [Range(18, 120)]
        [Required(ErrorMessage = "please provide your age")]
        public int Age { get; set; }

        [Required(ErrorMessage = "please provide your Gender")]
        public string Gender { get; set; }

        [DataType(DataType.EmailAddress, ErrorMessage = "please provide your email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "please provide the username")]
        [StringLength(20, MinimumLength = 6)]
        public string Username { get; set; }

        [Required(ErrorMessage = "please provide your password")]
        [StringLength(30, MinimumLength = 6)]
        public string Password { get; set; }

        [Compare("Password")]
        [Display(Name = "Confirm password")]
        public string Confirm_Password { get; set; }

        [Required(ErrorMessage = "please provide your address")]
        public string Address { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "please provide your phonenumer")]
        public long Phone_Number { get; set; }

        public bool Subscription { get; set; }

    }
}